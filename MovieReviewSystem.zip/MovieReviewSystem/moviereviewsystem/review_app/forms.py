from django import forms 

from .models import Review

class ReviewForm(forms.ModelForm):
    class Meta:
        STATUS = (
            ('published', 'published'),
            ('not published', 'not published')
        )

        GENERES = (
            ('horror', 'horror'),
            ('Action', 'Action'),
            ('scifi', 'scifi'),
            ('comedy', 'comedy'),
            ('thriller', 'thriller'),
        )
        model = Review
        fields = ['movie_title', 'director', 'review', 'rating', 'reviewer_email', 'status', 'generes']
        widgets = {
            'movie_title': forms.TextInput(attrs={'class': 'form-control'}),
            'director': forms.TextInput(attrs={'class': 'form-control'}),
            'review': forms.Textarea(attrs={'class': 'form-control'}),
            'rating': forms.TextInput(attrs={'class': 'form-control'}),
            'reviewer_email': forms.EmailInput(attrs={'class': 'form-control'}),
            'status' : forms.Select(choices=STATUS, attrs={'class': 'form-control'}),
            'generes' : forms.Select(choices=GENERES, attrs={'class': 'form-control'}),
        }