from django.urls import path

from .views import base, create_review, show_review, update_review, delete_review

urlpatterns = [
    path('', base),
    path('create/', create_review, name='create'),
    path('show/', show_review, name='show'),
    path('update/<int:pk>/', update_review, name='update'),
    path('delete/<int:pk>/', delete_review, name='delete'),
]