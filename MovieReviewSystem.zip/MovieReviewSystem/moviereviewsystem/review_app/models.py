from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator

# Create your models here.
class Review(models.Model):
    STATUS = (
        ('published', 'published'),
        ('not published', 'not published')
    )

    GENERES = (
        ('horror', 'horror'),
        ('Action', 'Action'),
        ('scifi', 'scifi'),
        ('comedy', 'comedy'),
        ('thriller', 'thriller'),
    )

    movie_title = models.CharField(max_length=200)
    director = models.CharField(max_length=100)
    review = models.TextField(max_length=300)
    rating = models.IntegerField(validators=[MinValueValidator(1), MaxValueValidator(5)])
    created_at = models.DateField(auto_now_add=True)
    reviewer_email = models.EmailField()
    status = models.CharField(choices=STATUS, max_length=20)
    generes = models.CharField(choices=GENERES, max_length=30)