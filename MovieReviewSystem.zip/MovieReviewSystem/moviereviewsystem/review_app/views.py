from django.shortcuts import render, redirect, get_object_or_404

from .forms import ReviewForm
from .models import Review

def base(request):
    return render(request, 'base.html')

def create_review(request):
    form = ReviewForm()
    if request.method == 'POST':
        form = ReviewForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('show')
    return render(request, 'review_app/create_review.html', {'form': form})


def show_review(request):
    reviews = Review.objects.all()
    return render(request, 'review_app/show_review.html', {'reviews': reviews})

def update_review(request, pk):
    review = get_object_or_404(Review, id=pk)
    form = ReviewForm(instance=review)
    if request.method == 'POST':
        form = ReviewForm(request.POST, instance=review)
        if form.is_valid():
            form.save()
            return redirect('show')
    return render(request, 'review_app/create_review.html', {'form': form})

def delete_review(request, pk):
    review = get_object_or_404(Review, id=pk)
    if request.method == 'POST':
        review.delete()
        return redirect('show')
    return render(request, 'review_app/delete_review.html', {'review': review})